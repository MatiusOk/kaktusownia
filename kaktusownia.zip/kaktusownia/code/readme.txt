This is the code for your game.

You don't need to manually add files to any project, files you add here will automatically be
compiled. Even if they're deep in subfolders.